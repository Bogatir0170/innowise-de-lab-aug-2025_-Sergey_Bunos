import json
api_response_json = """
{
"store": "StoreHub",
"orders": [
    {"id": 1, "total": 50},
    {"id": 2, "total": 200},
    {"id": 3, "total": 150}
		]
 }
"""
response = json.loads(api_response_json)
orders_list = response["orders"]
high_value_orders = [order for order in orders_list if order["total"] > 100]
response["high_value_orders"] = high_value_orders
result_json = json.dumps(response, indent=4)
print(result_json)
