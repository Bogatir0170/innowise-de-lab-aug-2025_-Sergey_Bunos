prices = [100, -50, 300, 40, 800]
prices.remove(-50)
prices.append(150)
prices.sort()
tax_prices = [prices * 1.2 for prices in prices if prices * 1.2 > 100]
print('Базовый прайс (очищенный):',  prices)
print('Цены с НДС (>100):', tax_prices)
print('Общая выручка:', sum(tax_prices))
print('Минимум:', min(tax_prices))
print('Максимум:', max(tax_prices))

